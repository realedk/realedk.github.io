# IronTrac Asset Selector

Adds two checkboxes above the grid in **Jobs → Pressure Test → Assets**:

- **Select all** selects every selectable asset in the current list. Unchecking it clears the list.
- **Select all but check valves** selects other assets and deselects assets whose Description contains “check valve” (case insensitive, including plural and hyphenated variants). Unchecking it clears the non-check-valve items.

The controls reflect individual row selections and work after navigating between jobs or reopening Assets. They use the site's normal checkbox clicks. They do not start, stage, save, or complete a pressure test.

## Install in Chrome

1. Open `chrome://extensions`.
2. Turn on **Developer mode** in the upper right.
3. Click **Load unpacked** and choose this `irontrac-asset-selector` folder (the folder containing `manifest.json`). If using the ZIP, extract it first.
4. Reload your IronTrac tab and open **Pressure Test → Assets**.

## Extension menu

Click the extension in Chrome's puzzle-piece menu (pin it for quicker access). Its **Enabled / Disabled** switch saves your preference. The **Refresh page** button beside the switch reloads the active tab. After either enabling or disabling, refresh each open IronTrac tab to apply the change. The menu displays this reminder and confirms when the setting is saved. The extension starts enabled.

## Selection scope

Selection applies to rows currently loaded in this grid and respects the current filters. Clear filters to include the full loaded list. It does not fetch other pages or assets that IronTrac has not loaded. Disabled row checkboxes are skipped. Check the displayed selection count before using IronTrac's own actions.

## Privacy and removal

The page script runs only on `https://app.irontrac.com/`. It contains no network requests, tracking, remote code, or background service. Its only Chrome permission is local storage, used solely for the enabled/disabled preference. Remove it from `chrome://extensions` whenever you want.

Built against the grouped Kendo Assets grid inspected on October 20, 2026. Future IronTrac layout changes may require updating its selectors.
